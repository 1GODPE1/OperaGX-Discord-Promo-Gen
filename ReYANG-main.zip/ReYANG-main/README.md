<h1 align="center">🔥 ReYANG: Yet Another Nitro Generator - Reborn🚀</h1>
<h1 align="center"><a href="https://github.com/Tenclea/YANG">The previous repository has been DMCA'd!</a></br>Be aware of scammers!</h1>

<p align="center">
  <a href="https://github.com/Tenclea/ReYANG/stargazers"><img src="https://img.shields.io/github/stars/Tenclea/ReYANG?style=flat"/></a>
  <a href="https://github.com/Tenclea/ReYANG"><img src="https://visitor-badge.laobi.icu/badge?page_id=tenclea.ReYANG"/></a>
  <a href="https://github.com/Tenclea/ReYANG/releases/"><img src="https://shields.io/github/downloads/tenclea/ReYANG/total?label=Downloads&logoColor=Green&color=Blue&style=flat"/></a>

  <br>
  <b>The most efficient nitro generator and checker you'll ever find.</b><br>
  Made with ❤ by <b><a href="https://github.com/tenclea">Tenclea</a></b>
  <br>
  If you liked this project, please consider <b>starring</b> it :)
</p>

<h2 align="center">👀 Previews</h2>

<p align="center">
   • Proxy Scrapper & Checker : <br>
   <img src="https://i.imgur.com/PQElB3e.png" title="YANG - By Tenclea : Proxy Scrapper & Checker"/>
   <br><br>
   • Main Nitro Codes Generator : <br>
   <img src="https://i.imgur.com/4QlDMU9.png" title="YANG - By Tenclea : Main Nitro Codes Generator"/>
</p>

## ✨ Main features

* 🔥 **Very fast code generator and checker (2000 attempts/minute)**
* 🤖 Fully automated, can generate and check codes infinitely, no need to restart every hour
* 🌐 Proxy scrapper and checker
* 💰 Automatically redeems nitro
* 📥 Download fresh proxies while checking codes
* 🔔 Full webhook support
* 📈 Real-time stats

## 💻 Setup
* Download a compiled release from the [release page](https://github.com/Tenclea/ReYANG/releases).
* Edit the config variables in the `config.yml` file as you like.
* (Optional) Paste fresh http(s)/socks proxies into `required/http-proxies.txt`/`required/socks-proxies.txt`.
* Start the generator by opening up the executable you downloaded !

## 📝 A Few Stats
![Alt](https://repobeats.axiom.co/api/embed/ce5b86fe5584279425f39bd614dbc0262b7a6e0c.svg "Repobeats analytics image")

## ⚠ Disclaimer

`Everything you can see here has been made for educational purposes and as a proof of concept.`  
`I do not promote the usage of my tools, and do not take responsibility for any bad usage of this tool.`  
`Stealing codes means stealing money from people and is against Discord's TOS. Don't.`
